const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { ENV } = require('./constants');
const { errorMiddleware } = require('./middlewares/error.middleware');
const { requestLoggerMiddleware } = require('./middlewares/logger.middleware');
const { requestIdMiddleware } = require('./middlewares/requestId.middleware');
const userRoutes = require('./routes/user.routes');

const app = express();

// Security middlewares
app.use(helmet());
app.use(
  cors({
    origin: process.env.CORS_ORIGIN || '*',
    credentials: true,
  })
);

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per window
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(limiter);

// Body parsers
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Request ID and logging
app.use(requestIdMiddleware);
app.use(requestLoggerMiddleware);

// Routes definition
app.get('/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Server is healthy',
    data: null,
    error: null,
  });
});

app.use('/api/v1/users', userRoutes);

// 404 handler
app.use((req, res, next) => {
  res.status(404).json({
    success: false,
    message: 'Resource not found',
    data: null,
    error: null,
  });
});

// Global Error Handler
app.use(errorMiddleware);

module.exports = app;
